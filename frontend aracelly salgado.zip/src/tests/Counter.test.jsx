import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import Counter from '../components/Counter'

test('el contador comienza en cero', () => {
  render(<Counter />)
  expect(screen.getByText('Valor: 0')).toBeInTheDocument()
})

test('aumenta el contador al presionar el botón', async () => {
  const user = userEvent.setup()
  render(<Counter />)

  await user.click(screen.getByRole('button', { name: /aumentar/i }))

  expect(screen.getByText('Valor: 1')).toBeInTheDocument()
})
