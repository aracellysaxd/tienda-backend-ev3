import { describe, it, expect } from 'vitest';
import { validarEdad } from '../utils/validarEdad';

describe('validarEdad', () => {
    it('deberia retornar "Mayor de edad" for age 18', () => {
        expect(validarEdad(18)).toBe("Mayor de edad");
    });
 });        