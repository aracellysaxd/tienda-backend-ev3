import { useState } from 'react'
import { Container, Nav, Navbar, Button, Badge } from 'react-bootstrap'
import { NavLink } from 'react-router-dom'
import { loginRequest, logoutRequest } from '../services/api'

function AppNavbar() {
  const [username, setUsername] = useState(localStorage.getItem('username') || '')
  const [rol, setRol] = useState(localStorage.getItem('rol') || '')

  const handleLoginRapido = async (user) => {
    try {
      const data = await loginRequest(user, '1234')
      setUsername(data.username)
      setRol(data.rol)
      window.location.reload()
    } catch (error) {
      alert('Error al conectar con el backend Spring Boot (puerto 8080)')
    }
  }

  const handleLogout = () => {
    logoutRequest()
    setUsername('')
    setRol('')
    window.location.reload()
  }

  return (
    <Navbar bg="dark" data-bs-theme="dark" expand="lg">
      <Container>
        <Navbar.Brand as={NavLink} to="/">
          Tienda Online FS2
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="menu-principal" />

        <Navbar.Collapse id="menu-principal">
          <Nav className="me-auto">
            <Nav.Link as={NavLink} to="/">Inicio</Nav.Link>
            <Nav.Link as={NavLink} to="/productos">Productos</Nav.Link>
            <Nav.Link as={NavLink} to="/perfil">Perfil y Storage</Nav.Link>
            {rol === 'ADMIN' && (
              <Nav.Link as={NavLink} to="/productos" className="text-warning fw-bold">
                Panel Admin (Gestión CRUD)
              </Nav.Link>
            )}
          </Nav>

          <div className="d-flex align-items-center gap-2">
            {username ? (
              <>
                <Badge bg={rol === 'ADMIN' ? 'warning' : 'info'} text="dark">
                  {username} ({rol})
                </Badge>
                <Button variant="outline-light" size="sm" onClick={handleLogout}>
                  Cerrar Sesión
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline-warning" size="sm" onClick={() => handleLoginRapido('admin')}>
                  Login Admin
                </Button>
                <Button variant="outline-info" size="sm" onClick={() => handleLoginRapido('cliente')}>
                  Login Cliente
                </Button>
              </>
            )}
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default AppNavbar